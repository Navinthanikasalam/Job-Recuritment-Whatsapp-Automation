// ============================================================
// SHINE CRAFT TECHNOLOGY
// File: config.js  (Chrome Extension — Unified Config)
// ⚠️  EDIT THIS FILE before loading the extension!
//     Paste your six Apps Script Web App URLs below.
// ============================================================

export const CONFIG_EXT = {

  // ─────────────────────────────────────────────────────────
  // REQUIRED: Paste your Google Apps Script Web App URLs here.
  //
  // How to get them:
  //   Apps Script Editor → Deploy → New deployment
  //   → Type: Web app → Execute as: Me → Who has access: Anyone
  //   → Deploy → Copy the URL
  //
  // The extension polls all non-empty URLs in this object every minute.
  // Configure up to 6 workflows:
  //   internship, job, program, event, workflow, custom.
  //
  // INTERNSHIP URL  →  internship automation Web App URL
  // JOB URL         →  job recruitment Web App URL
  // PROGRAM URL     →  training/program automation Web App URL
  // EVENT URL       →  webinar/event automation Web App URL
  // WORKFLOW URL    →  custom workflow automation Web App URL
  // CUSTOM URL      →  additional automation Web App URL
  // ─────────────────────────────────────────────────────────
  WEB_APP_URLS: {
    internship: 'https://script.google.com/macros/s/AKfycbx5DEraUi-B0dnspGfBgQwALGXYgwzOkvYKR61PpbUoWLr6WzNNNLQecFjM_86Jq_NaeQ/exec',
    job: 'https://script.google.com/macros/s/AKfycbyFD7PqhZH-YTLyPpxCaUzR9KMhwa3-Wi9lMcRdiJiEMPGcnUup_uGE6dwQpiId7-20/exec',
    program: '', // Future: Training/program automation
    event: '', // Future: Event automation (webinars, hackathons, etc.)
    workflow: '', // Future: Custom workflow automation
    custom: '', // Future: Custom implementation
  },

  // ─────────────────────────────────────────────────────────
  // Polling & Retry intervals (Chrome minimum = 1 minute)
  // ─────────────────────────────────────────────────────────
  POLL_INTERVAL_MIN: 1,    // Check both sheets every 1 minute
  RETRY_INTERVAL_MIN: 5,    // Retry failed items every 5 minutes

  // ─────────────────────────────────────────────────────────
  // Timing (milliseconds)
  // ─────────────────────────────────────────────────────────
  SEND_TIMEOUT_MS: 30000,  // 30 sec max wait per send (Chrome may clamp the underlying alarm to ~1 min for packed extensions — that's fine, it's just an upper bound on stuck-item detection)
  CLOSE_TAB_DELAY_MS: 3000,   // 3 sec after send before closing tab
  INTER_MESSAGE_DELAY_MS: 5000,   // 5 sec gap between messages (avoids WA ban)

  // ─────────────────────────────────────────────────────────
  // WhatsApp Web selectors (update only if WA changes its UI)
  // ─────────────────────────────────────────────────────────
  WA_SEND_BTN_SELECTOR: 'button[aria-label="Send"]',
  WA_MSG_BOX_SELECTOR: 'div[contenteditable="true"][data-tab="10"]',
  WA_CHAT_READY_SELECTOR: 'div[data-tab="10"]',

  // ─────────────────────────────────────────────────────────
  // Branding
  // ─────────────────────────────────────────────────────────
  COMPANY_NAME: 'Shine Craft Technology',
};
