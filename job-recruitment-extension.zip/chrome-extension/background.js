// ============================================================
// SHINE CRAFT TECHNOLOGY
// File: background.js  (Chrome Extension — Service Worker)
// Version: 2.3.0  — Survives MV3 service-worker suspension
// Purpose: Polls Google Sheets queue, opens WhatsApp Web tabs,
//          coordinates message delivery for Internship AND
//          Job Recruitment workflows.
//
// BUGS FIXED (v2.2.0):
//  BUG 1 — logError was declared `async`. JSON.stringify on a
//           string with getOwnPropertyNames throws TypeError.
//           The unhandled rejection showed as "line 483 error".
//           Fix: logError is now a plain sync function that
//           fires an internal async IIFE (fire-and-forget).
//
//  BUG 2 — chrome.notifications.create() was called WITHOUT a
//           string notificationId as the first argument.
//           Manifest V3 requires it — crashes without it.
//           Fix: unique string ID added to every call.
//
//  BUG 3 — notifyServer() had `throw err` at the bottom, which
//           propagated unhandled into onWhatsAppSent/Failed and
//           crashed the entire send callback chain.
//           Fix: notifyServer never throws; errors are logged.
//
//  BUG 4 — toggleEnabled() stored raw msg.enabled (could be
//           undefined/non-boolean). Fix: coerced with !!enabled.
//
// BUGS FIXED (v2.3.0):
//  BUG 5 — The 30s send-confirmation timer used raw setTimeout,
//           stored only in the module-level `sendTimeoutId`.
//           MV3 kills idle service workers (~30s), which discards
//           pending setTimeout callbacks AND resets isProcessing/
//           currentQueueItem/whatsAppTabId to their initial values.
//           A send stuck waiting for confirmation when the worker
//           was recycled would never be marked failed, and
//           inProgressQueueIds would keep it blocked forever.
//           Fix: the confirmation timeout is now a chrome.alarms
//           alarm (survives suspension), and pollQueue/
//           processNextInBatch check chrome.storage's `currentSend`
//           (persisted) as the source of truth instead of trusting
//           in-memory flags alone. A startup reconciliation pass
//           also fails/clears anything left stuck by a prior crash.
//
// BUGS FIXED (v2.4.1):
//  BUG 6 — ROOT CAUSE of "automation never runs on its own, only
//           the Poll Queue Now button works": chrome.alarms are
//           NOT guaranteed to survive a browser restart or an idle
//           service-worker recycle. The POLL alarm was only ever
//           created in onInstalled, which fires on install/update
//           only — not on every browser start. Once the alarm was
//           silently dropped, automatic polling stopped forever,
//           while manual polling (onMessage, not alarms) kept
//           working, hiding the problem.
//           Fix: ensureAlarmsExist() checks chrome.alarms.get() and
//           recreates any missing alarm. It's called (1) at module
//           top level — runs on every service-worker start no
//           matter what woke it, (2) in onInstalled, (3) in
//           onStartup, and (4) on every GET_STATUS call from the
//           popup, so opening the popup also self-heals it.
// ============================================================

'use strict';

import { CONFIG_EXT } from './config.js';

// ─── Global safety net for any unhandled rejections ─────────
self.addEventListener('unhandledrejection', function (event) {
  try {
    var reason = event.reason;
    logError('unhandledrejection',
      reason && reason.message ? reason.message : String(reason));
  } catch (_) {}
});

self.addEventListener('error', function (event) {
  try {
    logError('globalError', event.message || String(event.error || 'Unknown'));
  } catch (_) {}
});

// ─── Module-level state ──────────────────────────────────────
var isProcessing     = false;var isPolling        = false;var whatsAppTabId    = null;
var currentQueueItem = null;

// ─── Alarm names ─────────────────────────────────────────────
var ALARM_POLL         = 'POLL_QUEUE';
var ALARM_RETRY        = 'RETRY_FAILED';
var SEND_TIMEOUT_PREFIX = 'SEND_TIMEOUT_'; // + queueId

// BUG 5 FIX: reconcile any send that was left "in progress" by a
// service worker that got killed/restarted before it could resolve.
// Runs on both onInstalled and onStartup so a recycle mid-send self-heals.
async function reconcileStuckSends() {
  try {
    var data = await storageGet(['currentSend', 'inProgressQueueIds']);

    // 1) If a send was in flight when the worker died, fail it now.
    if (data.currentSend && data.currentSend.queueId) {
      log('Reconciling stuck currentSend from previous worker instance: ' + data.currentSend.queueId);
      await onWhatsAppFailed(
        data.currentSend.queueId,
        'Recovered after service worker restart (send never confirmed)',
        null
      );
    }

    // 2) Clear any inProgressQueueIds entries older than 2x the send timeout —
    //    these are orphaned markers that would otherwise block that item forever.
    var inProgressMap = (data.inProgressQueueIds && typeof data.inProgressQueueIds === 'object')
                        ? data.inProgressQueueIds : {};
    var cutoff = Date.now() - (2 * CONFIG_EXT.SEND_TIMEOUT_MS);
    var changed = false;
    for (var qId in inProgressMap) {
      if (inProgressMap[qId] < cutoff) {
        delete inProgressMap[qId];
        changed = true;
      }
    }
    if (changed) {
      await storageSet({ inProgressQueueIds: inProgressMap });
      log('Cleared stale inProgressQueueIds entries.');
    }
  } catch (err) {
    logError('reconcileStuckSends', err);
  }
}

function resetProcessingState() {
  isProcessing = false;
  currentQueueItem = null;
}

async function clearInProgressQueueIds() {
  try {
    await storageSet({ inProgressQueueIds: {} });
  } catch (_) {}
}

function runSafeAsync(fn, context) {
  return function () {
    var args = Array.prototype.slice.call(arguments);
    Promise.resolve()
      .then(function () {
        return fn.apply(null, args);
      })
      .catch(function (err) {
        logError(context || 'runSafeAsync', err);
      });
  };
}

// ─── Chrome API promise wrappers ─────────────────────────────
function storageGet(keys) {
  return new Promise(function (resolve, reject) {
    chrome.storage.local.get(keys, function (result) {
      if (chrome.runtime.lastError) {
        return reject(new Error(chrome.runtime.lastError.message));
      }
      resolve(result);
    });
  });
}

function storageSet(items) {
  return new Promise(function (resolve, reject) {
    chrome.storage.local.set(items, function () {
      if (chrome.runtime.lastError) {
        return reject(new Error(chrome.runtime.lastError.message));
      }
      resolve();
    });
  });
}

function tabsQuery(queryInfo) {
  return new Promise(function (resolve, reject) {
    chrome.tabs.query(queryInfo, function (tabs) {
      if (chrome.runtime.lastError) {
        return reject(new Error(chrome.runtime.lastError.message));
      }
      resolve(tabs);
    });
  });
}

function tabsUpdate(tabId, updateProps) {
  return new Promise(function (resolve, reject) {
    chrome.tabs.update(tabId, updateProps, function (tab) {
      if (chrome.runtime.lastError) {
        return reject(new Error(chrome.runtime.lastError.message));
      }
      resolve(tab);
    });
  });
}

function tabsCreate(createProps) {
  return new Promise(function (resolve, reject) {
    chrome.tabs.create(createProps, function (tab) {
      if (chrome.runtime.lastError) {
        return reject(new Error(chrome.runtime.lastError.message));
      }
      resolve(tab);
    });
  });
}

function tabsRemove(tabId) {
  return new Promise(function (resolve, reject) {
    chrome.tabs.remove(tabId, function () {
      if (chrome.runtime.lastError) {
        return reject(new Error(chrome.runtime.lastError.message));
      }
      resolve();
    });
  });
}

function tabsSendMessage(tabId, message) {
  return new Promise(function (resolve, reject) {
    chrome.tabs.sendMessage(tabId, message, function (response) {
      if (chrome.runtime.lastError) {
        return reject(new Error(chrome.runtime.lastError.message));
      }
      resolve(response);
    });
  });
}

// ─── Get all configured endpoint objects ─────────────────────
function getConfiguredEndpoints() {
  var urls = [];
  if (CONFIG_EXT.WEB_APP_URLS && typeof CONFIG_EXT.WEB_APP_URLS === 'object') {
    var entries = Object.entries(CONFIG_EXT.WEB_APP_URLS);
    for (var i = 0; i < entries.length; i++) {
      var workflow = entries[i][0];
      var url      = entries[i][1];
      if (typeof url === 'string' && url.trim() && !url.includes('PASTE_YOUR')) {
        urls.push({ workflow: workflow, url: url.trim() });
      }
    }
  }
  // Legacy single-URL fallback
  if (urls.length === 0 &&
      CONFIG_EXT.WEB_APP_URL &&
      typeof CONFIG_EXT.WEB_APP_URL === 'string') {
    urls.push({ workflow: 'internship', url: CONFIG_EXT.WEB_APP_URL.trim() });
  }
  return urls;
}

function getEndpointForWorkflow(workflow) {
  var endpoints = getConfiguredEndpoints();
  if (!workflow) return endpoints[0] || null;
  var key = String(workflow).toLowerCase();
  for (var i = 0; i < endpoints.length; i++) {
    if (endpoints[i].workflow === key) return endpoints[i];
  }
  return endpoints[0] || null;
}

function buildWebAppUrl(endpoint, action) {
  if (!endpoint || !endpoint.url) return '';
  var url = String(endpoint.url || '').trim();
  if (!url) return '';
  var separator = url.indexOf('?') === -1 ? '?' : '&';
  return url + separator + 'action=' + encodeURIComponent(action || 'getPending');
}

async function fetchAppScriptEndpoint(endpoint, action) {
  var candidates = [];
  if (endpoint && endpoint.url) {
    var base = String(endpoint.url).trim();
    candidates.push(buildWebAppUrl(endpoint, action));
    if (base) candidates.push(base);
  }

  var lastError = null;
  for (var i = 0; i < candidates.length; i++) {
    var url = candidates[i];
    if (!url) continue;

    try {
      var res = await fetch(url, { method: 'GET', cache: 'no-store' });
      var bodyText = await res.text().catch(function () { return ''; });
      var trimmed = (bodyText || '').trim();

      if (!res.ok) {
        throw new Error('HTTP ' + res.status + ' from ' + (endpoint.workflow || 'unknown') + ': ' + trimmed.substring(0, 140));
      }

      if (!trimmed) {
        throw new Error('Empty response from ' + (endpoint.workflow || 'unknown') + '. Check the Apps Script deployment.');
      }

      if (trimmed.indexOf('<!DOCTYPE') === 0 || trimmed.indexOf('<html') === 0) {
        throw new Error('Received an HTML page from ' + (endpoint.workflow || 'unknown') + '. This usually means the Apps Script Web App is not deployed or published correctly.');
      }

      try {
        var json = JSON.parse(trimmed);
        if (!json || !json.success) {
          throw new Error((json && json.error) || 'API returned success:false for ' + (endpoint.workflow || 'unknown'));
        }
        return json;
      } catch (parseErr) {
        throw new Error('Response from ' + (endpoint.workflow || 'unknown') + ' is not valid JSON. Check your Apps Script Web App URL and deployment.');
      }
    } catch (err) {
      lastError = err;
    }
  }

  throw lastError || new Error('Unable to reach Apps Script endpoint for ' + (endpoint.workflow || 'unknown'));
}

// ─── Extension lifecycle ─────────────────────────────────────
// BUG 6 FIX: chrome.alarms are NOT guaranteed to survive a browser
// restart / service-worker respawn (Chrome's own docs: "Alarm
// persistence following browser restarts isn't currently guaranteed").
// onInstalled only fires on install/update, so if the alarm silently
// disappears after a normal Chrome restart or an idle SW recycle,
// automatic polling stops forever and only the manual "Poll Queue Now"
// button (which goes through onMessage, not alarms) keeps working.
// Fix: check-and-recreate any missing alarm. This runs at MODULE
// TOP LEVEL (not inside a listener) so it fires on every single
// service-worker start, no matter what event woke it up.
async function ensureAlarmsExist() {
  try {
    var pollAlarm = await chrome.alarms.get(ALARM_POLL);
    if (!pollAlarm) {
      await chrome.alarms.create(ALARM_POLL, { periodInMinutes: CONFIG_EXT.POLL_INTERVAL_MIN });
      log('POLL alarm was missing — recreated it.');
    }
    var retryAlarm = await chrome.alarms.get(ALARM_RETRY);
    if (!retryAlarm) {
      await chrome.alarms.create(ALARM_RETRY, { periodInMinutes: CONFIG_EXT.RETRY_INTERVAL_MIN });
      log('RETRY alarm was missing — recreated it.');
    }
  } catch (err) {
    logError('ensureAlarmsExist', err);
  }
}
ensureAlarmsExist(); // fires on every service-worker start, unconditionally

chrome.runtime.onInstalled.addListener(runSafeAsync(async function () {
  log('Extension v2.4.0 installed — Internship + Job Recruitment');

  await ensureAlarmsExist();

  // Only reset counters on a fresh install, not on every reconciliation.
  var existing = await storageGet(['isEnabled']);
  if (existing.isEnabled === undefined) {
    await storageSet({
      isEnabled:            true,
      totalSent:            0,
      totalFailed:          0,
      lastPollAt:           null,
      lastSentAt:           null,
      errorLog:             [],
      internshipSent:       0,
      internshipFailed:     0,
      jobSent:              0,
      jobFailed:            0,
      recentlySentQueueIds: {},
      inProgressQueueIds:   {},
      currentSend:          null,
    });
  }

  await reconcileStuckSends();
  log('Storage initialised. Alarms set.');
}, 'onInstalled'));

chrome.runtime.onStartup.addListener(runSafeAsync(async function () {
  log('Browser started — verifying alarms.');
  // BUG 6 FIX: don't assume alarms survived the restart — verify.
  await ensureAlarmsExist();
  // BUG 5 FIX: the service worker (and its module-level state) is
  // fresh on every startup/recycle. Reconcile anything a previous
  // instance left half-finished before polling resumes.
  await reconcileStuckSends();
}, 'onStartup'));

// ─── Alarm handler ───────────────────────────────────────────
chrome.alarms.onAlarm.addListener(runSafeAsync(async function (alarm) {
  if (alarm.name === ALARM_POLL || alarm.name === ALARM_RETRY) {
    await pollQueue();
    return;
  }

  // BUG 5 FIX: send-confirmation timeout, now alarm-based so it
  // survives service worker suspension (setTimeout does not).
  if (alarm.name.indexOf(SEND_TIMEOUT_PREFIX) === 0) {
    var queueId = alarm.name.slice(SEND_TIMEOUT_PREFIX.length);
    try {
      var cs = await storageGet('currentSend');
      if (cs.currentSend && cs.currentSend.queueId === queueId) {
        log('Timeout waiting for send confirmation on ' + queueId);
        await onWhatsAppFailed(queueId, 'Send timeout (' + (CONFIG_EXT.SEND_TIMEOUT_MS / 1000) + 's)', whatsAppTabId);
      }
    } catch (err) {
      logError('sendTimeoutAlarm', err);
    }
  }
}, 'onAlarm'));

// ─── Message handler (popup + content script) ────────────────
// Every case has its own {} block to allow const/let declarations safely.
chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  var message = msg && typeof msg === 'object' ? msg : {};
  (async function () {
    try {
      switch (message.action) {

        case 'POLL_NOW': {
          await pollQueue();
          sendResponse({ success: true });
          break;
        }

        case 'GET_STATUS': {
          // BUG 6 FIX: cheap extra safety net — the popup polls this
          // every 3s while open, so use it to self-heal a dropped alarm
          // without waiting for the next onStartup.
          await ensureAlarmsExist();
          var status = await getStatus();
          sendResponse({ success: true, data: status });
          break;
        }

        case 'TOGGLE_ENABLED': {
          await toggleEnabled(message.enabled);
          sendResponse({ success: true });
          break;
        }

        case 'WHATSAPP_SENT': {
          var tabIdSent = sender.tab ? sender.tab.id : undefined;
          await onWhatsAppSent(message.queueId, tabIdSent);
          sendResponse({ success: true });
          break;
        }

        case 'WHATSAPP_FAILED': {
          var tabIdFailed = sender.tab ? sender.tab.id : undefined;
          await onWhatsAppFailed(message.queueId, message.reason, tabIdFailed);
          sendResponse({ success: true });
          break;
        }

        case 'NEXT_MESSAGE': {
          await processNextInBatch();
          sendResponse({ success: true });
          break;
        }

        default: {
          sendResponse({ success: false, error: 'Unknown action: ' + message.action });
          break;
        }
      }
    } catch (err) {
      logError('onMessage', err);
      sendResponse({ success: false, error: safeString(err && err.message ? err.message : err, 'Unexpected error') });
    }
  })();
  return true; // keep message channel open for async sendResponse
});

// ─── CORE: Poll both workflow queues ─────────────────────────
async function pollQueue() {
  if (isPolling) {
    log('Polling already in progress — skipping duplicate poll.');
    return;
  }

  // BUG 5 FIX: don't trust only the in-memory isProcessing flag — a
  // freshly-recycled service worker starts with isProcessing=false
  // even if a send is genuinely still in flight. Check persisted state.
  var inFlight = await storageGet('currentSend');
  if (isProcessing || (inFlight.currentSend && inFlight.currentSend.queueId)) {
    log('Polling skipped because a message is already being processed.');
    return;
  }

  isPolling = true;

  try {
    var stored = await storageGet('isEnabled');
    if (!stored.isEnabled) {
      log('Automation disabled — skipping poll.');
      return;
    }

    await storageSet({ lastPollAt: new Date().toISOString() });

    var endpoints = getConfiguredEndpoints();
    if (endpoints.length === 0) {
      log('No Apps Script URLs configured in config.js — nothing to poll.');
      return;
    }

    log('Polling ' + endpoints.length + ' workflow(s): ' +
        endpoints.map(function (e) { return e.workflow; }).join(', '));

    var allPending = [];

    for (var i = 0; i < endpoints.length; i++) {
      var endpoint = endpoints[i];
      try {
        var json = await fetchAppScriptEndpoint(endpoint, 'getPending');
        var items = Array.isArray(json.data) ? json.data : [];
        log('  ' + endpoint.workflow + ': ' + items.length + ' pending message(s)');

        for (var j = 0; j < items.length; j++) {
          items[j].workflow  = items[j].workflow || endpoint.workflow;
          items[j].sourceUrl = endpoint.url;
          items[j].sourceKey = endpoint.workflow;
        }

        allPending = allPending.concat(items);

      } catch (endpointErr) {
        logError('pollQueue.' + endpoint.workflow, endpointErr.message);
      }
    }

    // Filter out recently sent items AND currently processing items
    var recentlyData = await storageGet('recentlySentQueueIds');
    var recentMap = (recentlyData.recentlySentQueueIds && typeof recentlyData.recentlySentQueueIds === 'object') 
                    ? recentlyData.recentlySentQueueIds 
                    : {};
    var now = Date.now();
    var TWO_MINUTES = 2 * 60 * 1000;
    
    // Clean up expired entries
    for (var k in recentMap) {
      if (now - recentMap[k] > TWO_MINUTES) {
        delete recentMap[k];
      }
    }

    // Also get currently-processing items (prevent re-polling same item during send)
    var processingData = await storageGet('inProgressQueueIds');
    var inProgressMap = (processingData.inProgressQueueIds && typeof processingData.inProgressQueueIds === 'object')
                        ? processingData.inProgressQueueIds
                        : {};

    // Filter out both recently sent AND in-progress items
    var filtered = [];
    for (var i = 0; i < allPending.length; i++) {
      var qId = allPending[i].queueId;
      if (inProgressMap[qId]) {
        log('  ⏳ Skipping ' + qId + ' (currently being sent to WhatsApp)');
      } else if (recentMap[qId]) {
        log('  ⏭️  Skipping ' + qId + ' (recently sent, awaiting server update)');
      } else {
        filtered.push(allPending[i]);
      }
    }

    await storageSet({ recentlySentQueueIds: recentMap });

    if (filtered.length === 0) {
      log('All queues empty — nothing to send.');
      return;
    }

    log('Total pending across all workflows: ' + filtered.length);
    await storageSet({ pendingBatch: filtered });
    await processNextInBatch();

  } catch (err) {
    logError('pollQueue', err.message);
  } finally {
    isPolling = false;
  }
}

// ─── CORE: Process messages one by one ───────────────────────
async function processNextInBatch() {
  var inFlight = await storageGet('currentSend');
  if (isProcessing || (inFlight.currentSend && inFlight.currentSend.queueId)) {
    log('Already processing — will resume after current send completes.');
    return;
  }

  var result = await storageGet('pendingBatch');
  var pendingBatch = result.pendingBatch;

  if (!pendingBatch || pendingBatch.length === 0) {
    log('Batch complete — all messages processed.');
    isProcessing = false;
    return;
  }

  try {
    isProcessing = true;
    currentQueueItem = normalizeQueueItem(pendingBatch[0]);

    // DUPLICATE FIX: Mark as in-progress IMMEDIATELY (before sending) so polling won't re-fetch it
    var inProgressData = await storageGet('inProgressQueueIds');
    var inProgressMap = (inProgressData.inProgressQueueIds && typeof inProgressData.inProgressQueueIds === 'object')
                        ? inProgressData.inProgressQueueIds
                        : {};
    inProgressMap[currentQueueItem.queueId] = Date.now();
    await storageSet({ inProgressQueueIds: inProgressMap });

    await storageSet({ pendingBatch: pendingBatch.slice(1) });
    await sendViaWhatsApp(currentQueueItem);
  } catch (err) {
    isProcessing = false;
    currentQueueItem = null;
    logError('processNextInBatch', err.message || String(err));
    await onWhatsAppFailed((pendingBatch[0] && pendingBatch[0].queueId) || '', err.message || 'Processing error', null);
  }
}

// ─── CORE: Open WhatsApp Web and send ────────────────────────
async function sendViaWhatsApp(item) {
  try {
    var message = item.message || '';
    if (!message) {
      throw new Error('No message body for workflow="' + item.workflow +
                      '" status="' + item.status + '"');
    }

    if (!item.phone) {
      throw new Error('No phone number for workflow="' + item.workflow + '"');
    }

    log('[' + item.workflow.toUpperCase() + '] → ' +
        (item.name || item.phone) + ' | ' + item.status);

    var waLink = buildWaLink(item.phone, message);
    var tabs   = await tabsQuery({ url: 'https://web.whatsapp.com/*' });

    if (tabs.length > 0 && tabs[0].id != null) {
      whatsAppTabId = tabs[0].id;
      try {
        await tabsUpdate(whatsAppTabId, { url: waLink, active: true });
      } catch (_) {
        var newTab = await tabsCreate({ url: waLink, active: true });
        whatsAppTabId = newTab.id;
      }
    } else {
      var tab = await tabsCreate({ url: waLink, active: true });
      whatsAppTabId = tab.id;
    }

    await storageSet({
      currentSend: {
        queueId:     item.queueId,
        phone:       item.phone,
        name:        item.name,
        status:      item.status,
        workflow:    item.workflow,
        message:     message,
        waLink:      waLink,
        initiatedAt: new Date().toISOString(),
      },
    });

    await triggerContentSend(whatsAppTabId, item.queueId);

    // BUG 5 FIX: use a chrome.alarms alarm instead of setTimeout — this
    // survives service worker suspension. Chrome enforces a 1-minute floor
    // on alarm delays for packed extensions, so we use that as the floor;
    // it's a slightly looser timeout than 30s but still self-heals reliably,
    // versus the old setTimeout which could be silently discarded entirely.
    var timeoutMinutes = Math.max(CONFIG_EXT.SEND_TIMEOUT_MS / 60000, 1);
    await chrome.alarms.create(SEND_TIMEOUT_PREFIX + item.queueId, { delayInMinutes: timeoutMinutes });

  } catch (err) {
    logError('sendViaWhatsApp', err.message || String(err));
    resetProcessingState();
    await onWhatsAppFailed(item.queueId, err.message || String(err), null);
  }
}

// ─── Callback: message delivered ─────────────────────────────
async function onWhatsAppSent(queueId, tabId) {
  try {
    // BUG 5 FIX: clear the alarm-based confirmation timeout for this item.
    if (queueId) { try { await chrome.alarms.clear(SEND_TIMEOUT_PREFIX + queueId); } catch (_) {} }

    var wf   = getSafeWorkflow(currentQueueItem);
    var name = getSafeName(currentQueueItem, 'candidate');
    log('✅ Sent confirmed: ' + queueId + ' [' + wf + ']');

    if (!queueId) {
      isProcessing = false;
      currentQueueItem = null;
      return;
    }

    // DUPLICATE FIX: Track this queueId as recently sent (don't re-process if next poll happens before server updates)
    var recentlyData = await storageGet('recentlySentQueueIds');
    var recentMap = (recentlyData.recentlySentQueueIds && typeof recentlyData.recentlySentQueueIds === 'object')
                    ? recentlyData.recentlySentQueueIds
                    : {};
    recentMap[queueId] = Date.now();
    await storageSet({ recentlySentQueueIds: recentMap });

    // DUPLICATE FIX: Remove from in-progress map
    var inProgressData = await storageGet('inProgressQueueIds');
    var inProgressMap = (inProgressData.inProgressQueueIds && typeof inProgressData.inProgressQueueIds === 'object')
                        ? inProgressData.inProgressQueueIds
                        : {};
    delete inProgressMap[queueId];
    await storageSet({ inProgressQueueIds: inProgressMap });

    // BUG 3 FIX: notifyServer no longer throws — wrapped in try/catch here too
    try {
      await notifyServer('markSent', {
        queueId:   queueId,
        sourceUrl: currentQueueItem ? currentQueueItem.sourceUrl : '',
        workflow:  wf,
      });
    } catch (_) {}

    // Update counters
    var counters = await storageGet(['totalSent', 'internshipSent', 'jobSent']);
    var update   = {
      totalSent:   (counters.totalSent  || 0) + 1,
      lastSentAt:  new Date().toISOString(),
      currentSend: null,
    };
    if (wf === 'job')        update.jobSent        = (counters.jobSent        || 0) + 1;
    if (wf === 'internship') update.internshipSent = (counters.internshipSent || 0) + 1;
    await storageSet(update);

    isProcessing = false;

    safeNotificationCreate(
      'sent',
      '✅ WhatsApp Sent! [' + wf.toUpperCase() + ']',
      'Delivered to ' + name
    );

    await delay(CONFIG_EXT.CLOSE_TAB_DELAY_MS);
    if (tabId) { try { await tabsRemove(tabId); } catch (_) {} }
    whatsAppTabId = null;

    await delay(CONFIG_EXT.INTER_MESSAGE_DELAY_MS);
    await processNextInBatch();
  } catch (err) {
    logError('onWhatsAppSent', err);
    resetProcessingState();
  }
}

// ─── Callback: message failed ─────────────────────────────────
async function onWhatsAppFailed(queueId, reason, tabId) {
  try {
    // BUG 5 FIX: clear the alarm-based confirmation timeout for this item.
    if (queueId) { try { await chrome.alarms.clear(SEND_TIMEOUT_PREFIX + queueId); } catch (_) {} }

    var wf   = getSafeWorkflow(currentQueueItem);
    var name = getSafeName(currentQueueItem, 'candidate');
    logError('onWhatsAppFailed [' + queueId + ']', reason);

    if (tabId) {
      try { await tabsRemove(tabId); } catch (_) {}
    }

    // BUG 3 FIX: wrapped in try/catch so a notifyServer failure can't crash this
    try {
      await notifyServer('markFailed', {
        queueId:   queueId,
        reason:    String(reason || ''),
        sourceUrl: currentQueueItem ? currentQueueItem.sourceUrl : '',
        workflow:  wf,
      });
    } catch (_) {}

    // DUPLICATE FIX: Remove from in-progress map
    var inProgressData = await storageGet('inProgressQueueIds');
    var inProgressMap = (inProgressData.inProgressQueueIds && typeof inProgressData.inProgressQueueIds === 'object')
                        ? inProgressData.inProgressQueueIds
                        : {};
    delete inProgressMap[queueId];
    await storageSet({ inProgressQueueIds: inProgressMap });

    var counters = await storageGet(['totalFailed', 'internshipFailed', 'jobFailed']);
    var update   = {
      totalFailed: (counters.totalFailed || 0) + 1,
      currentSend: null,
    };
    if (wf === 'job')        update.jobFailed        = (counters.jobFailed        || 0) + 1;
    if (wf === 'internship') update.internshipFailed = (counters.internshipFailed || 0) + 1;
    await storageSet(update);

    isProcessing = false;

    safeNotificationCreate(
      'failed',
      '❌ Send Failed [' + wf.toUpperCase() + ']',
      'Could not deliver to ' + name + ': ' + String(reason || '')
    );

    await delay(CONFIG_EXT.INTER_MESSAGE_DELAY_MS);
    await processNextInBatch();
  } catch (err) {
    logError('onWhatsAppFailed', err);
    resetProcessingState();
  }
}

// ─── Helper: normalise any queue item shape ───────────────────
function normalizeQueueItem(item) {
  if (!item || typeof item !== 'object') {
    return {
      queueId: '', phone: '', message: '', name: '',
      status: '', workflow: 'internship', sourceUrl: '', sourceKey: 'internship',
    };
  }
  var workflow = String(
    item.workflow || item.workflowType || item.source || 'internship'
  ).toLowerCase();

  return {
    queueId:       String(item.queueId       || item.id            || item.rowId        || ''),
    phone:         String(item.phone         || item.phoneNumber   || '').trim(),
    message:       String(item.message       || item.msg           || '').trim(),
    name:          String(item.name          || item.candidateName || item.fullName      || '').trim(),
    status:        String(item.status        || item.workflowStatus|| '').trim(),
    role:          String(item.role          || item.position      || '').trim(),
    interviewDate: String(item.interviewDate || ''),
    interviewTime: String(item.interviewTime || ''),
    meetingLink:   String(item.meetingLink   || ''),
    taskLink:      String(item.taskLink      || ''),
    deadline:      String(item.deadline      || item.taskDeadline  || ''),
    feedbackLink:  String(item.feedbackLink  || ''),
    workflow:      workflow,
    sourceUrl:     String(item.sourceUrl     || ''),
    sourceKey:     String(item.sourceKey     || workflow),
  };
}

// ─── Helper: build WhatsApp Web deep-link ────────────────────
function buildWaLink(phone, message) {
  var cleaned = String(phone || '').replace(/\D/g, '');
  return 'https://web.whatsapp.com/send?phone=' +
         encodeURIComponent(cleaned) +
         '&text=' +
         encodeURIComponent(message || '');
}

async function triggerContentSend(tabId, queueId) {
  if (!tabId) return;
  for (var attempt = 0; attempt < 4; attempt++) {
    try {
      var response = await tabsSendMessage(tabId, { action: 'SEND_NOW' });
      if (response && response.success) {
        log('Content script accepted send request for ' + queueId);
        return;
      }
    } catch (err) {
      log('Send trigger attempt ' + (attempt + 1) + ' failed for ' + queueId + ': ' + (err.message || String(err)));
    }
    await delay(1500);
  }
}

// ─── Helper: notify Apps Script server ───────────────────────
// BUG 3 FIX: This function NEVER throws. All errors are logged internally.
// Callers do not need try/catch around this.
async function notifyServer(action, body) {
  var url = body ? body.sourceUrl : '';
  if (!url || url.includes('PASTE_YOUR')) return; // URL not configured yet

  try {
    var res = await fetch(url, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify(Object.assign({ action: action }, body)),
    });

    if (!res.ok) {
      var errBody = await res.text().catch(function () { return res.statusText || ''; });
      logError('notifyServer.' + action,
               'HTTP ' + res.status + ': ' + errBody.substring(0, 120));
      return; // do NOT throw — must not crash the send flow
    }

    var json = await res.json().catch(function () { return null; });
    if (!json || !json.success) {
      logError('notifyServer.' + action,
               (json && json.error) || 'Server returned success:false');
    }
  } catch (err) {
    logError('notifyServer.' + action, err.message);
    // Intentionally NOT re-throwing — a server notification failure
    // must never crash the WhatsApp send confirmation flow.
  }
}

// ─── Helper: read extension status for popup ─────────────────
async function getStatus() {
  var data = await storageGet([
    'isEnabled', 'totalSent', 'totalFailed',
    'internshipSent', 'internshipFailed',
    'jobSent', 'jobFailed',
    'lastPollAt', 'lastSentAt',
    'pendingBatch', 'errorLog', 'currentSend',
  ]);
  return Object.assign({}, data, {
    pendingCount: (data.pendingBatch || []).length,
    isProcessing: isProcessing,
  });
}

// ─── Helper: toggle automation on/off ────────────────────────
// BUG 4 FIX: coerce to boolean with !! so undefined/null never stored
async function toggleEnabled(enabled) {
  await storageSet({ isEnabled: !!enabled });
  log('Automation ' + (enabled ? 'ENABLED' : 'DISABLED'));
}

// ─── Utility ─────────────────────────────────────────────────
function delay(ms) {
  return new Promise(function (resolve) { setTimeout(resolve, ms); });
}

function log(msg) {
  try {
    console.log('[ShCraft BG v2.1] ' + new Date().toISOString() + ' | ' + safeString(msg, '')); 
  } catch (_) {}
}

function safeString(value, fallback) {
  try {
    if (value === null || value === undefined) return fallback;
    if (typeof value === 'string') return value;
    if (value instanceof Error) return value.message || String(value);
    if (typeof value === 'symbol') return value.toString();
    if (typeof value === 'object') {
      try { return JSON.stringify(value); } catch (_) { return Object.prototype.toString.call(value); }
    }
    return String(value);
  } catch (_) {
    return fallback;
  }
}

function getSafeWorkflow(item) {
  try {
    if (!item || typeof item !== 'object') return 'unknown';
    var workflow = item.workflow || item.workflowType || item.source || item.type || 'unknown';
    return safeString(workflow, 'unknown').toLowerCase();
  } catch (_) {
    return 'unknown';
  }
}

function getSafeName(item, fallback) {
  try {
    if (!item || typeof item !== 'object') return fallback;
    return safeString(item.name || item.candidateName || item.fullName || fallback, fallback);
  } catch (_) {
    return fallback;
  }
}

function safeNotificationCreate(kind, title, message) {
  try {
    if (!chrome || !chrome.notifications || typeof chrome.notifications.create !== 'function') return;
    var notificationId = 'wa_' + safeString(kind, 'notify') + '_' + Date.now() + '_' + Math.floor(Math.random() * 100000);
    chrome.notifications.create(notificationId, {
      type: 'basic',
      iconUrl: 'icons/icon48.png',
      title: safeString(title, 'WhatsApp'),
      message: safeString(message, ''),
    });
  } catch (err) {
    logError('safeNotificationCreate', err);
  }
}

// BUG 1 FIX: logError is a plain SYNCHRONOUS function.
// It logs to console immediately, then fires an async IIFE internally
// (fire-and-forget) to write to storage.
// Callers must NOT await this function — it is intentionally void.
function logError(context, msg) {
  var safeContext = safeString(context, 'unknown');
  var safeMsg = safeString(msg, 'Unknown error');

  try {
    console.error('[ShCraft BG ERROR] [' + safeContext + '] ' + safeMsg);
  } catch (_) {}

  try {
    (function () {
      storageGet(['errorLog'])
        .catch(function () { return {}; })
        .then(function (result) {
          var errorLog = (result && Array.isArray(result.errorLog))
                         ? result.errorLog : [];
          var entry    = { time: new Date().toISOString(), context: safeContext, msg: safeMsg };
          var updated  = [entry].concat(errorLog).slice(0, 50);
          try {
            return storageSet({ errorLog: updated }).catch(function () {});
          } catch (_) { return; }
        })
        .catch(function () {});
    }());
  } catch (_) { /* swallow — logging must not throw */ }
}
